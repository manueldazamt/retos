package com.example.mintic.Box.repository.crud;

import org.springframework.data.repository.CrudRepository;

import com.example.mintic.Box.model.Message;

public interface CrudRepositoryMessage extends CrudRepository<Message,Integer>{

    
}
