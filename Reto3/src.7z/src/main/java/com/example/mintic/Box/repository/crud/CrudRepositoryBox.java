package com.example.mintic.Box.repository.crud;
import org.springframework.data.repository.CrudRepository;
import com.example.mintic.Box.model.Box;

public interface CrudRepositoryBox extends CrudRepository<Box, Integer>{

}
