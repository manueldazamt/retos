package com.example.mintic.Box.repository.crud;

import org.springframework.data.repository.CrudRepository;

import com.example.mintic.Box.model.Category;

public interface CrudRepositoryCategory extends CrudRepository<Category,Integer>{

    
}
