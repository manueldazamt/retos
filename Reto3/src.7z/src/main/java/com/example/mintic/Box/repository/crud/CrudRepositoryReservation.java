package com.example.mintic.Box.repository.crud;
import org.springframework.data.repository.CrudRepository;
import com.example.mintic.Box.model.Reservation;

public interface CrudRepositoryReservation  extends CrudRepository<Reservation,Integer>{
    
}
