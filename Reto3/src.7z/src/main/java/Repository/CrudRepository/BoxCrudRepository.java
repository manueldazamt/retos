package Repository.CrudRepository;

import entities.Box;
import org.springframework.data.repository.CrudRepository;

public interface BoxCrudRepository extends CrudRepository<Box,Integer> {
}
